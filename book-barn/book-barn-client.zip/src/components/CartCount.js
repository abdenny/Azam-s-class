import React from 'react'
import { connect } from 'react-redux'

function CartCount(props) {
    return (
        <h1>Cart Count: {props.totalCartItems}</h1>
    )
}

const mapStateToProps = (state) => {
    return {
        totalCartItems: state.cartItems.length  
    }
}

export default connect(mapStateToProps)(CartCount) 




